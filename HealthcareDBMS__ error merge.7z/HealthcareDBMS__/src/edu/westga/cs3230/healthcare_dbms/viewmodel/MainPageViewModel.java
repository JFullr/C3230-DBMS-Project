package edu.westga.cs3230.healthcare_dbms.viewmodel;

import java.util.ArrayList;
import java.util.HashMap;

import edu.westga.cs3230.healthcare_dbms.io.database.DatabaseConnector;
import edu.westga.cs3230.healthcare_dbms.model.RawQueryResult;
import edu.westga.cs3230.healthcare_dbms.model.QueryResultStorage;
import query.utils.SQLData;

/**
 * View-model for the MainPageCodeBehind.
 *
 * @author 
 */
public class MainPageViewModel {
	
	private QueryResultStorage queryResults;
	
	private DatabaseConnector database;

	/**
	 * Instantiates a new MainPageViewModel
	 * 
	 * @precondition none
	 * @postcondition 
	 * 
	 */
	public MainPageViewModel() {
		this.queryResults = new QueryResultStorage();
		this.database = new DatabaseConnector();
	}
	
<<<<<<< HEAD
	public boolean attemptLogin(String username, String password) {
		HealthcareQueryResult result = this.database.attemptLogin(username, password);
		if(result.getTuples().size() != 1){
			return false;
		}
		HashMap<String, SQLData> data = result.getTuples().get(0);
		if(data.get(key))
		return true;
	}
	
	public ArrayList<HealthcareQueryResult> getLastResult() {
=======
	public ArrayList<RawQueryResult> getLastResult() {
>>>>>>> e5ef3ea3056841fdbdfd71d51e02c7421e958158
		return this.queryResults.getLatestResults();
	}

	public QueryResultStorage getQueryStorage() {
		return this.queryResults;
	}

	public void attemptLogin(String username, String password) {

	}
}
