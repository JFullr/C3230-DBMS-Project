package edu.westga.cs3230.healthcare_dbms.model.dal;

public class UserPasswordStore {

}
