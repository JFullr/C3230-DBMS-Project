package edu.westga.cs3230.healthcare_dbms.viewmodel;

import java.util.ArrayList;
import java.util.HashMap;

import edu.westga.cs3230.healthcare_dbms.io.database.HealthcareDatabase;
import edu.westga.cs3230.healthcare_dbms.model.HealthcareQueryResult;
import edu.westga.cs3230.healthcare_dbms.model.QueryResultStorage;
import query.utils.SQLData;

/**
 * View-model for the MainPageCodeBehind.
 *
 * @author 
 */
public class MainPageViewModel {
	
	private QueryResultStorage queryResults;
	
	private HealthcareDatabase database;

	/**
	 * Instantiates a new MainPageViewModel
	 * 
	 * @precondition none
	 * @postcondition 
	 * 
	 */
	public MainPageViewModel(String dbUrl) {
		this.queryResults = new QueryResultStorage();
		this.database = new HealthcareDatabase(dbUrl);
	}


	/**
	 * Loads Query results from the database into the front panel.
	 * 
	 * @precondition none
	 * @postcondition none
	 */
	public void loadDataFromDatabase() {
		for (HealthcareQueryResult result : this.database.getQueryResults()) {
			try {
				///TODO
				//this.frontpanel.add(result);
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
	}

	/**
	 * Performs a query on the operated database
	 *
	 * @param query the query
	 */
	public boolean callQuery(String query) {
		boolean success = false;
		try {
			success = this.database.callQuery(query);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return success;
	}
	
	public boolean attemptLogin(String username, String password) {
		HealthcareQueryResult result = this.database.attemptLogin(username, password);
		if(result.getTuples().size() != 1){
			return false;
		}
		HashMap<String, SQLData> data = result.getTuples().get(0);
		if(data.get(key))
		return true;
	}
	
	public ArrayList<HealthcareQueryResult> getLastResult() {
		return this.queryResults.getLatestResults();
	}

	public QueryResultStorage getQueryStorage() {
		return this.queryResults;
	}

}
