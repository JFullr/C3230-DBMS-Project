package query.utils;
public enum SQL_TYPE {
	
	ARRAY,
	BOOLEAN,
	CHAR,
	DATE,
	DOUBLE,
	FLOAT,
	INT,
	STRING
	
}
