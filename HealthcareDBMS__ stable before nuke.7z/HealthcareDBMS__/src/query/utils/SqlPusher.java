package query.utils;

public class SqlPusher {

}
