package edu.westga.cs3230.healthcare_dbms.io.data;

/**
 * Converts HealthcareQueryResult to query objects.
 * 
 * Possibly unneeded
 * 
 */
public class HealthcareQueryWriter {
	
	/**
	 * Instantiates a new HealthcareQueryWriter
	 *
	 */
	public HealthcareQueryWriter() {
		
	}

	
}
