package edu.westga.cs3230.healthcare_dbms.io.data;

/**
 * Converts data to HealthcareQueryResult objects.
 * 
 * Possibly unneeded
 * 
 */
public class HealthcareQueryReader {


	/**
	 * Instantiates a new HealthcareQueryReader
	 *
	 */
	public HealthcareQueryReader() {
		//
	}


}
