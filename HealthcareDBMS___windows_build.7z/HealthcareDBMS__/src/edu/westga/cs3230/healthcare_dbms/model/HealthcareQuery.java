package edu.westga.cs3230.healthcare_dbms.model;

public class HealthcareQuery {
	
	///TODO data handler for a query to be executed in db client

}
